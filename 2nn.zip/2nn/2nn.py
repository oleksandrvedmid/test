import ray
from ray import serve
#from transformers import pipeline
#from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, Pipeline

from ray.serve.dag import InputNode
from ray.serve.drivers import DAGDriver


@serve.deployment(route_prefix="/Translation", num_replicas=1, ray_actor_options={"num_cpus": 0.5, "num_gpus": 0})
class Translation:
  # Take the message to return as an argument to the constructor.
  def __init__(self):
      #self.model = pipeline("translation_en_to_fr", model="t5-small")
      a = 1
      
  async def __call__(self, request):
      data = await request.body()
      
      translation = "Hello"
      return translation
  

       


Translation.deploy()


translation_bind = Translation.bind()



#translation_handle = serve.run(translation_bind, name="translation_app")






